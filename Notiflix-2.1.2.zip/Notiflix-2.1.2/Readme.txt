Thanks for downloading Notiflix. 
 ----- 
Notiflix is a JavaScript library for client-side non-blocking notifications, popup boxes, loading indicators, and more to that makes your web projects much better.
 ----- 
Notiflix is fully customizable. You may visit the Documentation page to learn how. 
 ----- 
https://www.notiflix.com/
https://www.notiflix.com/documentation